import React from "react";

const Horoscope = () => {
  return <div>Horoscope</div>;
};

export default Horoscope;
