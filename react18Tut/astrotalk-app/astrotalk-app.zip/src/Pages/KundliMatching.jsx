import React from "react";

const KundliMatching = () => {
  return <div>KundliMatching</div>;
};

export default KundliMatching;
