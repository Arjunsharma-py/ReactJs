import React from "react";

const FeatureBox = (props) => {
  return (
    <div className="intro-chat-container">
      <div className="intro-chat-icon"></div>
      <h4>Chat</h4>
    </div>
  );
};

export default FeatureBox;
