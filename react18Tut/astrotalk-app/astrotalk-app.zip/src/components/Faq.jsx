import React from "react";

const Faq = () => {
  return (
    <>
      <div className="faq-section">
        <h2>FAQ'S ABOUT ASTROLOGY</h2>
        <div className="faq">
          <h3>Why Is Astrology So Accurate?</h3>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam
            quam maxime incidunt ut blanditiis illo nesciunt nihil tenetur
            magnam quod neque, dolore laboriosam. Dignissimos necessitatibus
            neque, perspiciatis unde optio earum? Illo, exercitationem? Amet,
            illum. Aliquam, sed nihil reiciendis quas expedita delectus vel a
            cumque reprehenderit est et eligendi, consequuntur voluptatibus
            dolor ex sequi consequatur voluptas animi inventore impedit
            provident debitis. Mollitia doloribus ut consequatur nisi totam quis
            blanditiis, earum culpa accusamus veritatis molestiae assumenda vero
            quae eius voluptatum consectetur quam nulla facilis explicabo
            expedita corporis repellendus aliquid? Quo, inventore iste? Corrupti
            ipsam praesentium aspernatur aperiam. Cupiditate sunt laboriosam
            beatae. Eaque, magni earum iste deleniti voluptatum consequatur?
            Voluptatum et blanditiis illo magni quas dolorem suscipit
            praesentium odit nostrum, nemo magnam at. Laudantium amet harum quas
            vel dignissimos nihil, sit sunt aperiam voluptate totam expedita
            tempora rerum hic nostrum doloribus sed at necessitatibus? Saepe ut
            optio minima dicta corporis. Tenetur, illum mollitia? Eum voluptates
            dolores quae, assumenda id praesentium quisquam. Quidem sed
            repudiandae officia, sit dolorum temporibus. Atque alias aspernatur,
            minus nulla eveniet expedita, dolores blanditiis facilis accusamus
            saepe laudantium aperiam. Dignissimos! Sapiente, perferendis totam,
            eos nobis, eaque quo ea aliquam architecto illo officiis velit
            itaque voluptates? Ipsum laudantium placeat voluptatem, commodi
            praesentium iure maxime officiis quia dolorum! Natus voluptatum
            cumque voluptates! Nostrum deleniti cumque id voluptatem enim eaque
            quas nesciunt eos, maxime modi ullam rem voluptatibus aliquid
            quibusdam accusamus molestias magnam nisi, sunt eum aliquam minima,
            quos ut. Nulla, voluptas eaque? Non qui illum molestiae labore
            similique beatae enim aspernatur perferendis aliquam ea eaque cumque
            exercitationem consectetur saepe, natus blanditiis facere fuga
            reprehenderit. Ex aut itaque eius excepturi possimus, eligendi
            tempore! Deleniti qui recusandae corporis tempore, provident fuga
            nulla nesciunt vitae doloremque soluta voluptatem id repellendus,
            molestias necessitatibus? Odit quis placeat incidunt pariatur, ullam
            molestias maiores natus labore sequi rem alias!
          </p>
          <h3>Why Is Astrology So Accurate?</h3>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam
            quam maxime incidunt ut blanditiis illo nesciunt nihil tenetur
            magnam quod neque, dolore laboriosam. Dignissimos necessitatibus
            neque, perspiciatis unde optio earum? Illo, exercitationem? Amet,
            illum. Aliquam, sed nihil reiciendis quas expedita delectus vel a
            cumque reprehenderit est et eligendi, consequuntur voluptatibus
            dolor ex sequi consequatur voluptas animi inventore impedit
            provident debitis. Mollitia doloribus ut consequatur nisi totam quis
            blanditiis, earum culpa accusamus veritatis molestiae assumenda vero
            quae eius voluptatum consectetur quam nulla facilis explicabo
            expedita corporis repellendus aliquid? Quo, inventore iste? Corrupti
            ipsam praesentium aspernatur aperiam. Cupiditate sunt laboriosam
            beatae. Eaque, magni earum iste deleniti voluptatum consequatur?
            Voluptatum et blanditiis illo magni quas dolorem suscipit
            praesentium odit nostrum, nemo magnam at. Laudantium amet harum quas
            vel dignissimos nihil, sit sunt aperiam voluptate totam expedita
            tempora rerum hic nostrum doloribus sed at necessitatibus? Saepe ut
            optio minima dicta corporis. Tenetur, illum mollitia? Eum voluptates
            dolores quae, assumenda id praesentium quisquam. Quidem sed
            repudiandae officia, sit dolorum temporibus. Atque alias aspernatur,
            minus nulla eveniet expedita, dolores blanditiis facilis accusamus
            saepe laudantium aperiam. Dignissimos! Sapiente, perferendis totam,
            eos nobis, eaque quo ea aliquam architecto illo officiis velit
            itaque voluptates? Ipsum laudantium placeat voluptatem, commodi
            praesentium iure maxime officiis quia dolorum! Natus voluptatum
            cumque voluptates! Nostrum deleniti cumque id voluptatem enim eaque
            quas nesciunt eos, maxime modi ullam rem voluptatibus aliquid
            quibusdam accusamus molestias magnam nisi, sunt eum aliquam minima,
            quos ut. Nulla, voluptas eaque? Non qui illum molestiae labore
            similique beatae enim aspernatur perferendis aliquam ea eaque cumque
            exercitationem consectetur saepe, natus blanditiis facere fuga
            reprehenderit. Ex aut itaque eius excepturi possimus, eligendi
            tempore! Deleniti qui recusandae corporis tempore, provident fuga
            nulla nesciunt vitae doloremque soluta voluptatem id repellendus,
            molestias necessitatibus? Odit quis placeat incidunt pariatur, ullam
            molestias maiores natus labore sequi rem alias!
          </p>
          <h3>Why Is Astrology So Accurate?</h3>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam
            quam maxime incidunt ut blanditiis illo nesciunt nihil tenetur
            magnam quod neque, dolore laboriosam. Dignissimos necessitatibus
            neque, perspiciatis unde optio earum? Illo, exercitationem? Amet,
            illum. Aliquam, sed nihil reiciendis quas expedita delectus vel a
            cumque reprehenderit est et eligendi, consequuntur voluptatibus
            dolor ex sequi consequatur voluptas animi inventore impedit
            provident debitis. Mollitia doloribus ut consequatur nisi totam quis
            blanditiis, earum culpa accusamus veritatis molestiae assumenda vero
            quae eius voluptatum consectetur quam nulla facilis explicabo
            expedita corporis repellendus aliquid? Quo, inventore iste? Corrupti
            ipsam praesentium aspernatur aperiam. Cupiditate sunt laboriosam
            beatae. Eaque, magni earum iste deleniti voluptatum consequatur?
            Voluptatum et blanditiis illo magni quas dolorem suscipit
            praesentium odit nostrum, nemo magnam at. Laudantium amet harum quas
            vel dignissimos nihil, sit sunt aperiam voluptate totam expedita
            tempora rerum hic nostrum doloribus sed at necessitatibus? Saepe ut
            optio minima dicta corporis. Tenetur, illum mollitia? Eum voluptates
            dolores quae, assumenda id praesentium quisquam. Quidem sed
            repudiandae officia, sit dolorum temporibus. Atque alias aspernatur,
            minus nulla eveniet expedita, dolores blanditiis facilis accusamus
            saepe laudantium aperiam. Dignissimos! Sapiente, perferendis totam,
            eos nobis, eaque quo ea aliquam architecto illo officiis velit
            itaque voluptates? Ipsum laudantium placeat voluptatem, commodi
            praesentium iure maxime officiis quia dolorum! Natus voluptatum
            cumque voluptates! Nostrum deleniti cumque id voluptatem enim eaque
            quas nesciunt eos, maxime modi ullam rem voluptatibus aliquid
            quibusdam accusamus molestias magnam nisi, sunt eum aliquam minima,
            quos ut. Nulla, voluptas eaque? Non qui illum molestiae labore
            similique beatae enim aspernatur perferendis aliquam ea eaque cumque
            exercitationem consectetur saepe, natus blanditiis facere fuga
            reprehenderit. Ex aut itaque eius excepturi possimus, eligendi
            tempore! Deleniti qui recusandae corporis tempore, provident fuga
            nulla nesciunt vitae doloremque soluta voluptatem id repellendus,
            molestias necessitatibus? Odit quis placeat incidunt pariatur, ullam
            molestias maiores natus labore sequi rem alias!
          </p>
          <h3>Why Is Astrology So Accurate?</h3>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam
            quam maxime incidunt ut blanditiis illo nesciunt nihil tenetur
            magnam quod neque, dolore laboriosam. Dignissimos necessitatibus
            neque, perspiciatis unde optio earum? Illo, exercitationem? Amet,
            illum. Aliquam, sed nihil reiciendis quas expedita delectus vel a
            cumque reprehenderit est et eligendi, consequuntur voluptatibus
            dolor ex sequi consequatur voluptas animi inventore impedit
            provident debitis. Mollitia doloribus ut consequatur nisi totam quis
            blanditiis, earum culpa accusamus veritatis molestiae assumenda vero
            quae eius voluptatum consectetur quam nulla facilis explicabo
            expedita corporis repellendus aliquid? Quo, inventore iste? Corrupti
            ipsam praesentium aspernatur aperiam. Cupiditate sunt laboriosam
            beatae. Eaque, magni earum iste deleniti voluptatum consequatur?
            Voluptatum et blanditiis illo magni quas dolorem suscipit
            praesentium odit nostrum, nemo magnam at. Laudantium amet harum quas
            vel dignissimos nihil, sit sunt aperiam voluptate totam expedita
            tempora rerum hic nostrum doloribus sed at necessitatibus? Saepe ut
            optio minima dicta corporis. Tenetur, illum mollitia? Eum voluptates
            dolores quae, assumenda id praesentium quisquam. Quidem sed
            repudiandae officia, sit dolorum temporibus. Atque alias aspernatur,
            minus nulla eveniet expedita, dolores blanditiis facilis accusamus
            saepe laudantium aperiam. Dignissimos! Sapiente, perferendis totam,
            eos nobis, eaque quo ea aliquam architecto illo officiis velit
            itaque voluptates? Ipsum laudantium placeat voluptatem, commodi
            praesentium iure maxime officiis quia dolorum! Natus voluptatum
            cumque voluptates! Nostrum deleniti cumque id voluptatem enim eaque
            quas nesciunt eos, maxime modi ullam rem voluptatibus aliquid
            quibusdam accusamus molestias magnam nisi, sunt eum aliquam minima,
            quos ut. Nulla, voluptas eaque? Non qui illum molestiae labore
            similique beatae enim aspernatur perferendis aliquam ea eaque cumque
            exercitationem consectetur saepe, natus blanditiis facere fuga
            reprehenderit. Ex aut itaque eius excepturi possimus, eligendi
            tempore! Deleniti qui recusandae corporis tempore, provident fuga
            nulla nesciunt vitae doloremque soluta voluptatem id repellendus,
            molestias necessitatibus? Odit quis placeat incidunt pariatur, ullam
            molestias maiores natus labore sequi rem alias!
          </p>
        </div>
      </div>
    </>
  );
};

export default Faq;
